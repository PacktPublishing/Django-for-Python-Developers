from django.apps import AppConfig


class SessionappConfig(AppConfig):
    name = 'sessionApp'
