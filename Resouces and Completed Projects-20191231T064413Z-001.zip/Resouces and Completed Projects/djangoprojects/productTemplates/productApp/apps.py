from django.apps import AppConfig


class ProductappConfig(AppConfig):
    name = 'productApp'
