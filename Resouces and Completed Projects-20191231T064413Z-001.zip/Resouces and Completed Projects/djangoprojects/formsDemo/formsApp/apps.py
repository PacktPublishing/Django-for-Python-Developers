from django.apps import AppConfig


class FormsappConfig(AppConfig):
    name = 'formsApp'
