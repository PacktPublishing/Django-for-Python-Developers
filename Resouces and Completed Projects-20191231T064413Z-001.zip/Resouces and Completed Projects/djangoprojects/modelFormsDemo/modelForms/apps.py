from django.apps import AppConfig


class ModelformsConfig(AppConfig):
    name = 'modelForms'
